package bmi;
import java.util.Scanner;
public class BMI {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Weight in Kg: ");
        double weight = input.nextDouble();
        System.out.print("Height in cm: ");
        double height = input.nextDouble();
        double compare = (weight * weight) / height;
        System.out.println(compare);
        if (compare < 18.5) {
            System.out.println("Underweight");
        } else if (compare >= 18.5 && compare < 25) {
            System.out.println("Normal");
        } else if (compare >= 25 && compare < 30) {
            System.out.println("Overweight");
        } else if (compare >= 30) {
            System.out.println("Obese");
        }
    }
}
